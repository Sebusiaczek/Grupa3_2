function [s,Aa,Ab]=vincinv(f1,l1,f2,l2,a,e2);
%{
Funkcja obliczajaca dlugosc lini geodeyjnej s metoda Vincenta
f1, f2 -> wspolrzedne fi punktu poczatkowego (1) i koncowego (2)
l1, l2 -> analogicznie do f1 i f2
%}

L=l2-l1;
% Przeniesienie na sfere do szerokosci zredukowanych
%---------------------------------------------------------%
b = a*sqrt(1-e2); % Obliczenie krotszej polosi elipsoidy
f = 1 - (b/a); % Obliczenie splaszczenia elipsoidy
U1 = atan((1-f)*tan(f1));
U2 = atan((1-f)*tan(f2)); % Obliczenie szerokosci zredukowanych
%---------------------------------------------------------%
% Rozpoczecie iteracji
i=0;
La=L;
while 1
    i=i+1;
    sd=sqrt((cos(U2)*sin(La))^2+(cos(U1)*sin(U2)-sin(U1)*cos(U2)*cos(La))^2);
    cd=sin(U1)*sin(U2)+cos(U1)*cos(U2)*cos(La); %cos(sigma)
    d=atan(sd/cd); % d to sigma
    sa=cos(U1)*cos(U2)*sin(La)/sd; % sa to sinus alfa
    c2dm=cd-2*sin(U1)*sin(U2)/(1-sa^2); % cos(2sigmam)
    
    C=(f/16)*(1-sa^2)*(4+f*(4-3*(1-sa^2)));
    Ls=La;
    La=L+(1-C)*f*sa*(d+C*sd*(c2dm+C*cd*(-1+2*c2dm^2)));
    if abs(La-Ls)<(0.000001/206265) break; end;
end;
% Tu tez trzeba bylo dopisac:
%---------------------------------------------------------%
u2 = ((a^2 - b^2)*(1-sa^2))/(b^2);
A = 1 + (u2/16384)*(4096+u2*(-768+u2*(320-175*u2)));
B = (u2/1024)*(256+u2*(-128+u2*(74-47*u2)));
dd = B*sd*(c2dm+0.25*B*(cd*(-1+2*c2dm^2)-(1/6)*B*c2dm*(-3+4*sd^2)*(-3+4*c2dm^2)));
%---------------------------------------------------------%
s=b*A*(d-dd);
Aa=atan((cos(U2)*sin(La))/(cos(U1)*sin(U2)-sin(U1)*cos(U2)*cos(La)));
Ab=atan((cos(U1)*sin(La))/(-sin(U1)*cos(U2)+cos(U1)*sin(U2)*cos(La)))+pi;

if Aa<0 Aa=Aa+pi;
   Ab=Ab+pi; end;